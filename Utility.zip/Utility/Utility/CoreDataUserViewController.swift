
//
//  UserViewController.swift
//  FinalCrudOperations
//
//  Created by Kalyani Reddy and Shubham Raut on 05/03/19.
//  Copyright © 2019 PK. All rights reserved.
//

import UIKit
import CoreData
var userArray:[User] = []


class CoreDataUserViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {
    
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchText: UITextField!
    
    
    var obj1 = Crud()
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        obj1.fetchData()
        
        // self.view.backgroundColor = UIColor.lightGray
    }
    
    
    /* Functions to intialize the table view with its cell */
    func numberOfSections(in tableView: UITableView) -> Int //Function to return number of sections used in the table view.
    {
        return 1
    }
    
    /* Funtion to show number of rows used in a particular section. */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return userArray.count
    }
    
    
    /* Function to return the cell type of a particular row in the section. */
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
        let name = userArray[indexPath.row]
        if name.firstName == nil && name.secondName == nil
        {
            tableView.reloadData()
        }
        else
        {
            cell.textLabel?.text = name.firstName! + " " + name.secondName!
            
        }
        return cell
    }
    
    
    
    /* Deleting a particular user in the table using editing style */
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        
        
        
        if editingStyle == .delete
        {
            obj1.deleteUser(search: searchText.text!)
        }
        tableView.reloadData()
    }
    
    
    /* Deleting a particular user in the table using a particular key */
    @IBAction func DeleteButton(_ sender: Any)
    {
        obj1.deleteUser(search: searchText.text!)
        tableView.reloadData()
    }
}




