//
//  ViewController.swift
//  FinalCrudOperations
//
//  Created by Kalyani Reddy and Shubham Raut on 05/03/19.
//  Copyright © 2019 PK. All rights reserved.
//

import UIKit
import CoreData


class CoreDataViewController: UIViewController {
    
    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var secondName: UITextField!
    @IBOutlet weak var search: UITextField!
    @IBOutlet weak var searchLabel: UILabel!
    @IBOutlet weak var frname: UITextField!
    @IBOutlet weak var srname: UITextField!
    var obj1 = Crud()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    /* Function used to create and save the user */
    @IBAction func createUser(_ sender: Any) {
           obj1.createUser(fname: firstName.text!, sname: secondName.text!)
    }
    
    
    /* Function used to retrieve the data stored in the container */
    @IBAction func retrieveUser(_ sender: Any)
    {
        let search2 = obj1.retrieveUser(search : search.text!)
        searchLabel.text! = search2
    }
    
    /* Function to update the given field */
    @IBAction func updateButton(_ sender: Any) {
        obj1.updateUser(fname: frname.text!, sname: srname.text!, search: search.text!)
    }
    
}
