//
//  Crud_File.swift
//  FinalCrudOperations
//
//  Created by Kalyani Reddy and Shubham Raut on 05/03/19.
//  Copyright © 2019 PK. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class Crud {
    
    
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    /* Function used to create and save the user */
    func createUser(fname : String, sname : String)
    {
        if fname != " " && sname != " "
        {
            let newUser = NSEntityDescription.insertNewObject(forEntityName: "User", into: context) //sets from which entity the user need to enter a specific value.
            newUser.setValue(fname, forKey: "firstName") //Set value as per the required field
            newUser.setValue(sname, forKey: "secondName") //Set value as per the required field
            do
            {
                try context.save() // To check and throw if any storing time of error occurs
            }
            catch
            {
                print(error) //Shows the error occurred
            }
        }
        else
        {
            print("Please enter first and second name")
        }
    }
    
    
    
    
    /* Function used to create and save the user */
    func updateUser(fname : String, sname : String, search : String)
    {
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User") //NSFetchRequest called from the NSObject file to fetch the stored data in the container as per the serach request.
        let searchString = search
        request.predicate = NSPredicate(format: "firstName == %@", searchString) //Matching made according to the search string and the data need to be searched using patterns.
        do
        {
            let result = try context.fetch(request)
            let objectUpdate = result[0] as! NSManagedObject
            
            objectUpdate.setValue(fname, forKey: "firstName") //Set value as per the required field
            objectUpdate.setValue(sname, forKey: "secondName") //Set value as per the required field
            do
            {
                try context.save() // To check and throw if any storing time of error occurs
            }
            catch
            {
                print(error) //Shows the error occurred
            }
        }
        catch{
            print(error)
        }
        
    }
    
    
    
    
    /* Function used to retrieve the data stored in the container */
    func retrieveUser(search : String) -> String
    {
        var concat : String = ""
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User") //NSFetchRequest called from the NSObject file to fect the stored data in the container as per the serach request.
        let searchString = search
        request.predicate = NSPredicate(format: "firstName == %@", searchString) //Matching made according to the search string and the data need to be searched using patterns.
        do
        {
            var result = try context.fetch(request)
            if result.count > 0
            {
                let firstname = (result[0] as AnyObject).value( forKey: "firstName") as! String // Access the first data from the container.
                let secondname = (result[0] as AnyObject).value( forKey: "secondName") as! String // access the second data from the container.
                concat = firstname + " " + secondname
                
            }
            else{
                concat = "No user"
            }
        }
        catch{
            print(error)
        }
        
        
        return concat
    }
    
    
    /* Function to retrieve all data */
    func fetchData()
    {
        do{
            userArray = try context.fetch(User.fetchRequest())
        }
        catch{
            print(error)
        }
    }
    
    
    
    
    /* Function to delete particular user */
    func deleteUser(search : String){
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "User") //NSFetchRequest called from the NSObject file to fetch the stored data in the container as per the serach request.
        let searchString = search
        request.predicate = NSPredicate(format: "firstName == %@", searchString) //Matching made according to the search string and the data need to be searched using patterns.
        do
        {
            let result = try context.fetch(request)
            let objectUpdate = result[0] as! NSManagedObject
            
            context.delete(objectUpdate)
            
            do
            {
                try context.save() // To check and throw if any storing time of error occurs
            }
            catch
            {
                print(error) //Shows the error occurred
            }
        }
        catch{
            print(error)
        }
    }
}

