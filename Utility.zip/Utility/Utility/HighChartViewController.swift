//
//  HighChartViewController.swift
//  Utility
//
//  Created by Rahul on 03/04/19.
//  Copyright © 2019 Rahul. All rights reserved.
//
import UIKit
import Highcharts


class HighChartViewController: UIViewController {
    var myhighcharts: MyHighCharts?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UIDevice.current.setValue(Int(UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func lineButton(_ sender: UIButton) {
    
        myhighcharts = MyHighCharts(frame: self.view.frame)
        
        let title = HITitle()
        title.text = "Solar Employment Growth by Sector, 2010-2016"
        
        let subtitle = HISubtitle()
        subtitle.text = "So urce: thesolarfoundation.com"
        
        let line1 = HILine()
        line1.name = "Installation"
        line1.data = [NSNumber(value: 43934), NSNumber(value: 52503), NSNumber(value: 57177), NSNumber(value: 69658), NSNumber(value: 97031), NSNumber(value: 119931), NSNumber(value: 137133), NSNumber(value: 154175)]
        
        let line2 = HILine()
        line2.name = "Manufacturing"
        line2.data = [NSNumber(value: 24916), NSNumber(value: 24064), NSNumber(value: 29742), NSNumber(value: 29851), NSNumber(value: 32490), NSNumber(value: 30282), NSNumber(value: 38121), NSNumber(value: 40434)]
        
        let line3 = HILine()
        line3.name = "Sales & Distribution"
        line3.data = [NSNumber(value: 11744), NSNumber(value: 17722), NSNumber(value: 16005), NSNumber(value: 19771), NSNumber(value: 20185), NSNumber(value: 24377), NSNumber(value: 32147), NSNumber(value: 39387)]
        
        let line4 = HILine()
        line4.name = "Project Development"
        line4.data = [NSNull(), NSNull(), NSNumber(value: 7988), NSNumber(value: 12169), NSNumber(value: 15112), NSNumber(value: 22452), NSNumber(value: 34400), NSNumber(value: 34227)]
        
        let line5 = HILine()
        line5.name = "Other"
        line5.data = [NSNumber(value: 12908), NSNumber(value: 5948), NSNumber(value: 8105), NSNumber(value: 11248), NSNumber(value: 8989), NSNumber(value: 11816), NSNumber(value: 18274), NSNumber(value: 18111)]
        
        
        let hiOptions = HIOptions()
        hiOptions.series = [line1, line2, line3, line4, line5]
        myhighcharts?.lineFunction(title: title, subtitle: subtitle, series: hiOptions.series)
        
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let lineViewController = storyboard.instantiateViewController(withIdentifier: "LineViewController") as? LineViewController
        lineViewController?.myhighcharts = myhighcharts
        
        self.navigationController?.pushViewController(lineViewController!, animated: true)
    }
    
    
    @IBAction func donutButton(_ sender: UIButton) {
    
        myhighcharts = MyHighCharts(frame: self.view.frame)
        let title = HITitle()
        title.text = "Browser market share, January, 2015 to May, 2015"
        
        let subtitle = HISubtitle()
        subtitle.text = "Source: <a href=\"http://netmarketshare.com/\">netmarketshare.com</a>"
        
        let hipie1 = HIPie()
        
        hipie1.data = [
            [ "name": "MSIE",
              "y": NSNumber(value: 56.33),
              "color": "#7cb5ec"
            ], [
                "name": "Firefox",
                "y": NSNumber(value: 10.38),
                "color": "#434348"
            ], [
                "name": "Chrome",
                "y": NSNumber(value: 24.03),
                "color": "#90ed7d"
            ], [
                "name": "Safari",
                "y": NSNumber(value: 4.77),
                "color": "#f7a35c"
            ], [
                "name": "Opera",
                "y": NSNumber(value: 0.91),
                "color": "#8085e9"
            ], [
                "y": NSNumber(value: 0.2),
                "color": "#f15c80"
            ]]
        
        
        let hipie2 = HIPie()
        hipie2.data = [
            ["name": "MSIE 6.0",
             "y": NSNumber(value: 1.06),
             "color": "rgb(175,232,255)"
            ], [
                "name": "MSIE 7.0",
                "y": NSNumber(value: 0.5),
                "color": "rgb(166,223,255)"
            ],[
                "name": "Firefox v31",
                "y": NSNumber(value: 0.33),
                "color": "rgb(118,118,123)"
            ], [
                "name": "Firefox v32",
                "y": NSNumber(value: 0.15),
                "color": "rgb(111,111,116)"
            ], [
                "name": "Firefox v38",
                "y": NSNumber(value: 2.31),
                "color": "rgb(79,79,84)"
            ], [
                "y": NSNumber(value: 1.02),
                "color": "rgb(73,73,78)"
            ], [
                "name": "Chrome v30.0",
                "y": NSNumber(value: 0.14),
                "color": "rgb(195,255,176)"
            ], [
                "name": "Chrome v31.0",
                "y": NSNumber(value: 1.24),
                "color": "rgb(191,255,172)"
            ],[
                "name": "Chrome v41.0",
                "y": NSNumber(value: 4.32),
                "color": "rgb(154,247,135)"
            ], [
                "name": "Chrome v42.0",
                "y": NSNumber(value: 3.68),
                "color": "rgb(151,244,132)"
            ], [
                "name": "Chrome v43.0",
                "y": NSNumber(value: 1.45),
                "color": "rgb(147,240,128)"
            ], [
                "name": "Safari v7.0",
                "y": NSNumber(value: 0.26),
                "color": "rgb(255,184,113)"
            ], [
                "name": "Safari v7.1",
                "y": NSNumber(value: 0.77),
                "color": "rgb(255,177,106)"
            ], [
                "name": "Safari v8.0",
                "y": NSNumber(value: 2.56),
                "color": "rgb(254,170,99)"
            ], [
                "name": "Opera v12.x",
                "y": NSNumber(value: 0.34),
                "color": "rgb(179,184,255)"
            ], [
                "name": "Opera v27",
                "y": NSNumber(value: 0.17),
                "color": "rgb(166,171,255)"
            ], [
                "name": "Opera v29",
                "y": NSNumber(value: 0.16),
                "color": "rgb(140,145,245)"
            ]]
        
        let hiOptions = HIOptions()
        hiOptions.series = [hipie1, hipie2]
        
        myhighcharts?.donutFunction(title: title, subtitle: subtitle, series: hiOptions.series)
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let lineViewController = storyboard.instantiateViewController(withIdentifier: "LineViewController") as? LineViewController
        lineViewController?.myhighcharts = myhighcharts
        self.navigationController?.pushViewController(lineViewController!, animated: true)
    }
    
    
    @IBAction func scatteredButton(_ sender: UIButton) {
        
        myhighcharts = MyHighCharts(frame: self.view.frame)
        
        let title = HITitle()
        title.text = "Height Versus Weight of 507 Individuals by Gender"
        
        let subtitle = HISubtitle()
        subtitle.text = "Source: Heinz  2003"
        
        let scatter1 = HIScatter()
        scatter1.name = "Female"
        scatter1.color = HIColor(rgba: 223, green: 83, blue: 83, alpha: 0.5)
        scatter1.data = [161.2, 1.2, 163.2, 1.3, 165.2, 1.6, 176.2, 1.8, 180.2, 2.3, 190.2, 2.7, 290.2, 2.3, 220.3, 1.4, 230.4, 1.3, 226.3, 1.3]
        
        let scatter2 = HIScatter()
        scatter2.name = "Male"
        scatter2.color = HIColor(rgba: 119, green: 152, blue: 191, alpha: 0.5)
        scatter2.data = [130.2, 1.2, 123.2, 1.4, 140.2, 1.6, 174.2, 1.1, 130.2, 1.4, 159.2, 2.4, 245.2, 1.6, 190.3, 1.8, 178.4, 3.4, 167.5, 1.1]
        
        
        let hiOptions = HIOptions()
        hiOptions.series = [scatter1, scatter2]
        
        myhighcharts?.scatteredFunction(title: title, subtitle: subtitle, series: hiOptions.series)
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let lineViewController = storyboard.instantiateViewController(withIdentifier: "LineViewController") as? LineViewController
        lineViewController?.myhighcharts = myhighcharts
        self.navigationController?.pushViewController(lineViewController!, animated: true)
    }
    
}

