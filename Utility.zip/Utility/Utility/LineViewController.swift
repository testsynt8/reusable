//
//  LineViewController.swift
//  Utility
//
//  Created by Rahul on 03/04/19.
//  Copyright © 2019 Rahul. All rights reserved.
//

import UIKit
import Highcharts

class LineViewController: UIViewController {
    
    var graphType = ""
    var myhighcharts: MyHighCharts?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let highChart = self.myhighcharts {
            self.view.addSubview(highChart)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
