//
//  MyHighCharts.swift
//  Utility
//
//  Created by Rahul on 03/04/19.
//  Copyright © 2019 Rahul. All rights reserved.
//

import Foundation
import UIKit

// Highchart is a cocoapod library which is used in our project for including the functionality of charts.
import Highcharts


class MyHighCharts: UIView {
    
    func lineFunction(title: HITitle , subtitle: HISubtitle, series: [HISeries]) {
        
        let chartView = HIChartView(frame: self.frame)
        
        let options = HIOptions()
        
        let yaxis = HIYAxis()
        yaxis.title = HITitle()
        yaxis.title.text = "Number of Employees"
        
        let legend = HILegend()
        legend.layout = "vertical"
        legend.align = "right"
        legend.verticalAlign = "middle"
        
        let plotoptions = HIPlotOptions()
        plotoptions.series = HISeries()
        plotoptions.series.label = HILabel()
        plotoptions.series.label.connectorAllowed = NSNumber(value: false)
        plotoptions.series.pointStart = NSNumber(value: 2010)
        
        let responsive = HIResponsive()
        
        let rules1 = HIRules()
        rules1.condition = HICondition()
        rules1.condition.maxWidth = 500
        rules1.chartOptions = [
            "legend": [
                "layout": "horizontal",
                "align": "center",
                "verticalAlign": "bottom"
            ]
        ]
        
        responsive.rules = [rules1]
        
        options.title = title
        options.subtitle = subtitle
        options.yAxis = [yaxis]
        options.legend = legend
        options.plotOptions = plotoptions
        options.series = series
        options.responsive = responsive
        
        chartView.options = options
        self.addSubview(chartView)
    }
    
    func donutFunction(title: HITitle , subtitle: HISubtitle, series: [HISeries]) {
        let chartView = HIChartView(frame: self.frame)
        
        let options = HIOptions()
        
        let chart = HIChart()
        chart.type = "pie"
        
        let yaxis = HIYAxis()
        yaxis.title = HITitle()
        yaxis.title.text = "Total percent market share"
        
        let plotoptions = HIPlotOptions()
        plotoptions.pie = HIPie()
        plotoptions.pie.shadow = NSNumber(value: false)
        plotoptions.pie.center = ["50%", "50%"]
        
        let tooltip = HITooltip()
        tooltip.valueSuffix = "%"
        
        let pie1 = HIPie()
        pie1.name = "Browsers"
        pie1.size = "60%"
        pie1.dataLabels = HIDataLabels()
        
        pie1.dataLabels.formatter = HIFunction(jsFunction: "function () { return this.y > 5 ? this.point.name : null; }")
        pie1.dataLabels.color = HIColor(hexValue: "ffffff")
        pie1.dataLabels.distance = NSNumber(value: -30) 
        
        options.chart = chart
        options.title = title
        options.subtitle = subtitle
        options.yAxis = [yaxis]
        options.tooltip = tooltip
        options.plotOptions = plotoptions
        options.series = series
        
        chartView.options = options
        self.addSubview(chartView)
        
        
    }
    
    func scatteredFunction(title: HITitle , subtitle: HISubtitle, series: [HISeries])
    {
        let chartView = HIChartView(frame: self.frame)
        
        let options = HIOptions()
        
        let chart = HIChart()
        chart.type = "scatter"
        chart.zoomType = "xy"
        
        let xaxis = HIXAxis()
        xaxis.title = HITitle()
        xaxis.title.text = "Height (cm)"
        xaxis.startOnTick = NSNumber(value: true)
        xaxis.endOnTick = NSNumber(value: true)
        xaxis.showLastLabel = NSNumber(value: true)
        
        let yaxis = HIYAxis()
        yaxis.title = HITitle()
        yaxis.title.text = "Weight (kg)"
        
        let legend = HILegend()
        legend.layout = "vertical"
        legend.align = "left"
        legend.verticalAlign = "top"
        legend.x = NSNumber(value: 100)
        legend.y = NSNumber(value: 70)
        legend.floating = NSNumber(value: true)
        legend.backgroundColor = HIColor(hexValue: "FFFFFF")
        legend.borderWidth = NSNumber(value: 1)
        
        let plotOptions = HIPlotOptions()
        plotOptions.scatter = HIScatter()
        plotOptions.scatter.marker = HIMarker()
        plotOptions.scatter.marker.radius = NSNumber(value: 5)
        plotOptions.scatter.marker.states = HIStates()
        plotOptions.scatter.marker.states.hover = HIHover()
        plotOptions.scatter.marker.states.hover.enabled = NSNumber(value: true)
        plotOptions.scatter.marker.states.hover.lineColor = HIColor(rgb: 100, green: 100, blue: 100)
        let state = HIStates()
        state.hover = HIHover()
        plotOptions.scatter.states = HIStates()
        plotOptions.scatter.states = state
        plotOptions.scatter.tooltip = HITooltip()
        plotOptions.scatter.tooltip.headerFormat = "<b>{series.name}</b><br>"
        plotOptions.scatter.tooltip.pointFormat = "{point.x} cm, {point.y} kg"
        
        let scatter1 = HIScatter()
        scatter1.name = "Female"
        scatter1.color = HIColor(rgba: 223, green: 83, blue: 83, alpha: 0.5)
        
        let scatter2 = HIScatter()
        scatter2.name = "Male"
        scatter2.color = HIColor(rgba: 119, green: 152, blue: 191, alpha: 0.5)
        
        options.chart = chart
        options.title = title
        options.subtitle = subtitle
        options.xAxis = [xaxis]
        options.yAxis = [yaxis]
        options.legend = legend
        options.plotOptions = plotOptions
        options.series = series
        
        chartView.options = options
        
        self.addSubview(chartView)
        
    }
}


